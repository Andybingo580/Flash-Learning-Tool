def load_flashcards_from_file(file_path):
    flashcards = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                question, answer = line.strip().split('|')
                flashcards.append({'question': question, 'answer': answer})
    except Exception as e:
        print(f"Error loading flashcards: {e}")
    return flashcards

def save_flashcards_to_file(flashcards, file_path):
    try:
        with open(file_path, 'w') as file:
            for flashcard in flashcards:
                file.write(f"{flashcard['question']}|{flashcard['answer']}\n")
    except Exception as e:
        print(f"Error saving flashcards: {e}")