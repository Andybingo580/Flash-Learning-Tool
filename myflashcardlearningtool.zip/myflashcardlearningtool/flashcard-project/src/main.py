from flashcards.flashcard_manager import FlashcardManager
import tkinter as tk
from tkinter import simpledialog, messagebox
import matplotlib.pyplot as plt
import random

class FlashcardApp:
    def __init__(self, root):
        self.manager = FlashcardManager()  # 初始化 FlashcardManager
        self.root = root
        self.root.title("Flashcard")  # 設定視窗標題
        
        # 移除問題標籤和輸入框
        # self.question_label = tk.Label(root, text="Question:")
        # self.question_label.pack()
        
        # self.question_entry = tk.Entry(root, width=50)
        # self.question_entry.pack()
        
        # 移除答案標籤和輸入框
        # self.answer_label = tk.Label(root, text="Answer:")
        # self.answer_label.pack()
        
        # self.answer_entry = tk.Entry(root, width=50)
        # self.answer_entry.pack()
        
        # 添加 Flashcard 按鈕
        self.add_button = tk.Button(root, text="Add Flashcard", command=self.add_flashcard)
        self.add_button.pack()
        
        # 顯示題庫按鈕
        self.show_button = tk.Button(root, text="Show Flashcards", command=self.show_flashcards)
        self.show_button.pack()
        
        # 開始測驗按鈕
        self.quiz_button = tk.Button(root, text="Start Quiz", command=self.start_quiz)
        self.quiz_button.pack()
        
        # 顯示結果的標籤
        self.result_label = tk.Label(root, text="")
        self.result_label.pack()
        
        # 顯示學習成效圖表按鈕
        self.plot_button = tk.Button(root, text="Show Efficiency Plot", command=self.show_efficiency_plot)
        self.plot_button.pack()

        # 存儲每次測驗的正確率
        self.efficiency_history = []

    def add_flashcard(self):
        # 獲取輸入的問題和答案
        question = simpledialog.askstring("Add Flashcard", "Enter the question:")
        answer = simpledialog.askstring("Add Flashcard", "Enter the answer:")
        if question and answer:
            # 添加 Flashcard 並清空輸入框
            self.manager.add_flashcard(question, answer)
            messagebox.showinfo("Success", "Flashcard added successfully!")
        else:
            messagebox.showwarning("Input Error", "Please enter both question and answer.")

    def edit_flashcard(self, flashcard):
        # 獲取新的問題和答案
        new_question = simpledialog.askstring("Edit Flashcard", "Enter the new question:", initialvalue=flashcard.question)
        new_answer = simpledialog.askstring("Edit Flashcard", "Enter the new answer:", initialvalue=flashcard.answer)
        if new_question and new_answer:
            # 更新 Flashcard 並保存
            flashcard.update_question(new_question)
            flashcard.answer = new_answer
            self.manager.save_flashcards()
            messagebox.showinfo("Success", "Flashcard edited successfully!")
            self.refresh_flashcards()
        else:
            messagebox.showwarning("Input Error", "Please enter both question and answer.")

    def delete_flashcard(self, flashcard):
        # 刪除 Flashcard 並保存
        self.manager.flashcards.remove(flashcard)
        self.manager.save_flashcards()
        messagebox.showinfo("Success", "Flashcard deleted successfully!")
        self.refresh_flashcards()

    def show_flashcards(self):
        # 創建新視窗顯示 flashcards
        self.flashcard_window = tk.Toplevel(self.root)
        self.flashcard_window.title("Flashcards")

        canvas = tk.Canvas(self.flashcard_window)
        scrollbar = tk.Scrollbar(self.flashcard_window, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        flashcards = self.manager.flashcards
        if flashcards:
            for flashcard in flashcards:
                frame = tk.Frame(scrollable_frame)
                frame.pack(fill=tk.X)

                question_label = tk.Label(frame, text=f"Q: {flashcard.question}")
                question_label.pack(side=tk.LEFT, padx=10)

                answer_label = tk.Label(frame, text=f"A: {flashcard.answer}")
                answer_label.pack(side=tk.LEFT, padx=10)

                edit_button = tk.Button(frame, text="Edit", command=lambda fc=flashcard: self.edit_flashcard(fc))
                edit_button.pack(side=tk.RIGHT, padx=10)

                delete_button = tk.Button(frame, text="Delete", command=lambda fc=flashcard: self.delete_flashcard(fc))
                delete_button.pack(side=tk.RIGHT, padx=10)
        else:
            messagebox.showinfo("Flashcards", "No flashcards available.")

    def refresh_flashcards(self):
        # 刷新 flashcards 顯示
        for widget in self.flashcard_window.winfo_children():
            widget.destroy()
        self.show_flashcards()

    def start_quiz(self):
        total_flashcards = len(self.manager.flashcards)
        if total_flashcards == 0:
            messagebox.showwarning("No Flashcards", "No flashcards available. Please add some flashcards first.")
            return
        
        # 隨機抽選題目
        flashcards = random.sample(self.manager.flashcards, min(10, total_flashcards))
        correct_answers = 0
        wrong_answers = 0
        for flashcard in flashcards:
            user_answer = simpledialog.askstring("Question", flashcard.question)
            if flashcard.check_answer(user_answer):
                correct_answers += 1
            else:
                wrong_answers += 1
        self.show_results(correct_answers, wrong_answers)

        # 記錄本次測驗的正確率
        total = correct_answers + wrong_answers
        if total > 0:
            efficiency = (correct_answers / total) * 100
            self.efficiency_history.append(efficiency)

    def show_results(self, correct_answers, wrong_answers):
        total = correct_answers + wrong_answers
        if total > 0:
            efficiency = (correct_answers / total) * 100
            if efficiency >= 80:
                feedback = "Great job!"
            elif efficiency >= 50:
                feedback = "Good effort, keep practicing!"
            else:
                feedback = "Needs improvement, keep trying!"
            result_text = (f"Correct Answers: {correct_answers}\n"
                           f"Wrong Answers: {wrong_answers}\n"
                           f"Learning Efficiency: {efficiency:.2f}%\n"
                           f"Feedback: {feedback}")
        else:
            result_text = "No questions answered yet."
        self.result_label.config(text=result_text)

    def show_efficiency_plot(self):
        if not self.efficiency_history:
            messagebox.showinfo("No Data", "No quiz data available.")
            return

        # 繪製學習成效圖表
        x_values = list(range(1, len(self.efficiency_history) + 1))
        plt.plot(x_values, self.efficiency_history, marker='o')
        plt.xlabel('Quiz Session')
        plt.ylabel('Efficiency (%)')
        plt.title('Learning Efficiency Over Time')
        plt.ylim(0, 100)
        plt.xticks(x_values)
        plt.grid(True)
        plt.show()

if __name__ == "__main__":
    root = tk.Tk()
    app = FlashcardApp(root)
    root.mainloop()