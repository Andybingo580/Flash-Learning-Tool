import json
from .flashcard import Flashcard

class FlashcardManager:
    def __init__(self, filename="flashcards.json"):
        self.flashcards = []
        self.correct_answers = 0
        self.wrong_answers = 0
        self.filename = filename
        self.load_flashcards()  # 加載已保存的 flashcards

    def add_flashcard(self, question, answer):
        self.flashcards.append(Flashcard(question, answer))
        self.save_flashcards()  # 保存 flashcards

    def save_flashcards(self):
        data = [{"question": fc.question, "answer": fc.answer} for fc in self.flashcards]
        with open(self.filename, 'w') as f:
            json.dump(data, f)  # 將 flashcards 保存到 JSON 文件

    def load_flashcards(self):
        try:
            with open(self.filename, 'r') as f:
                data = json.load(f)
                self.flashcards = [Flashcard(d["question"], d["answer"]) for d in data]
        except FileNotFoundError:
            self.flashcards = []  # 如果文件不存在，初始化為空列表

    def find_flashcard(self, question):
        for flashcard in self.flashcards:
            if flashcard.question == question:
                return flashcard  # 返回找到的 flashcard
        return None

    def delete_flashcard(self, question):
        flashcard = self.find_flashcard(question)
        if flashcard:
            self.flashcards.remove(flashcard)
            self.save_flashcards()  # 保存變更後的 flashcards
            return True
        return False