import unittest
from src.flashcards.flashcard_manager import FlashcardManager
from src.flashcards.flashcard import Flashcard

class TestFlashcardManager(unittest.TestCase):

    def setUp(self):
        self.manager = FlashcardManager()
        self.flashcard1 = Flashcard("What is the capital of France?", "Paris")
        self.flashcard2 = Flashcard("What is 2 + 2?", "4")

    def test_add_flashcard(self):
        self.manager.add_flashcard(self.flashcard1)
        self.assertIn(self.flashcard1, self.manager.get_flashcards())

    def test_remove_flashcard(self):
        self.manager.add_flashcard(self.flashcard1)
        self.manager.remove_flashcard(self.flashcard1)
        self.assertNotIn(self.flashcard1, self.manager.get_flashcards())

    def test_get_flashcards(self):
        self.manager.add_flashcard(self.flashcard1)
        self.manager.add_flashcard(self.flashcard2)
        flashcards = self.manager.get_flashcards()
        self.assertEqual(len(flashcards), 2)
        self.assertIn(self.flashcard1, flashcards)
        self.assertIn(self.flashcard2, flashcards)

if __name__ == '__main__':
    unittest.main()