import unittest
from src.flashcards.flashcard import Flashcard

class TestFlashcard(unittest.TestCase):

    def setUp(self):
        self.flashcard = Flashcard("What is the capital of France?", "Paris")

    def test_display(self):
        self.assertEqual(self.flashcard.display(), "Question: What is the capital of France?")

    def test_check_answer_correct(self):
        self.assertTrue(self.flashcard.check_answer("Paris"))

    def test_check_answer_incorrect(self):
        self.assertFalse(self.flashcard.check_answer("London"))

if __name__ == '__main__':
    unittest.main()