# Flashcard 項目

這個項目是一個簡單的 flashcard 應用程序，允許用戶創建、管理和學習 flashcards。它旨在幫助用戶有效地學習和記憶信息。

(1)程式功能

- 創建和管理帶有問題和答案的 flashcards。
- 顯示 flashcards 進行學習。
- 驗證用戶答案。
- 添加和刪除 flashcards。
- 藉由回答正確率提供學習圖表。(以作答正確率為縱軸，測驗次數為橫軸作圖)

(2)使用方式
   0.安裝requirements.txt內的模組
   1.點選add flashcards 增加題目與答案(兩個都要填)
   2.點選show flashcards 打開題目庫 (edit 可以編輯題目 delete可以刪除題目)
   3.點選start quiz 可以測試自己
   4.點選show efficiency plot 可以畫出習圖表

(3)程式架構
```
flashcard-project
├── src
│   ├── __init__.py
│   ├── main.py
│   ├── flashcards
│   │   ├── __init__.py
│   │   ├── flashcard.py
│   │   └── flashcard_manager.py
│   └── utils
│       ├── __init__.py
│       └── helper.py
├── tests
│   ├── __init__.py
│   ├── test_flashcard.py
│   └── test_flashcard_manager.py
├── requirements.txt
└── README.md
```

(4)開發過程



## 使用

要運行 flashcard 應用程序，執行以下命令：
```
python src/main.py
```

按照屏幕上的指示創建和學習你的 flashcards。

## 測試

要運行 flashcard 應用程序的測試，使用以下命令：
```
pytest
```


