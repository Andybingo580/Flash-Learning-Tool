from flask import Flask, render_template, request, redirect, url_for
from models import db, Flashcard

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///flashcards.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

@app.route('/')
def index():
    try:
        flashcards = Flashcard.query.all()
        return render_template('index.html', flashcards=flashcards)
    except Exception as e:
        return f"Error: {e}"  # 顯示詳細錯誤

@app.route('/quiz/<int:card_id>', methods=['GET', 'POST'])
def quiz(card_id):
    flashcard = Flashcard.query.get(card_id)
    if request.method == 'POST':
        answer = request.form['answer']
        correct = (answer.strip().lower() == flashcard.answer.lower())
        return render_template('quiz.html', flashcard=flashcard, correct=correct, answer=answer)
    return render_template('quiz.html', flashcard=flashcard)

with app.app_context():
    if not Flashcard.query.first():  # 如果資料庫是空的
        sample_card = Flashcard(question="What is the capital of France?", answer="Paris")
        db.session.add(sample_card)
        db.session.commit()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # 創建資料庫表格
    app.run(debug=True)

