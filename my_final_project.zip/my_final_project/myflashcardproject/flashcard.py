##########################
# Flash Card Web Project #
##########################

# 1. Import Necessary Libraries
from flask import Flask, render_template, request, redirect, url_for  # Flask handles web app creation and HTTP requests
import sqlite3                                     # SQLite for storing questions and user data
from rapidfuzz import fuzz                        # Rapidfuzz for flexible answer comparison
import random                                     # Random module for initial random selection logic
from konlpy.tag import Okt    
import os
import matplotlib.pyplot as plt  
import matplotlib      # For generating progress charts
matplotlib.use('Agg')  # 使用非圖形後端
                

# Ensure proper Unicode handling
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 2. Initialize Flask App
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 用於加密 session
# 3. Database Setup
DATABASE = "flashcards.db"  # Name of the SQLite database file

import sqlite3


DATABASE = "flashcards.db"

conn = sqlite3.connect(DATABASE)
cursor = conn.cursor()
cursor.execute("SELECT * FROM flashcards")
flashcards = cursor.fetchall()
conn.close()

def init_db():
    """
    Function to initialize the database and create necessary tables.
    This function will create three tables:
    - flashcards: stores questions and answers
    - stats: tracks correct and wrong answers
    - cycles: tracks accuracy of each 10-question cycle
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Table to store flashcards
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS flashcards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            subject TEXT DEFAULT 'General',
            language TEXT DEFAULT 'Korean',
            explanation TEXT
        )
    ''')
    
    # Table to store stats
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            correct INTEGER DEFAULT 0,
            wrong INTEGER DEFAULT 0,
            subject TEXT NOT NULL
        )
    ''')
    
    # Table to store cycles
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cycles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cycle_number INTEGER NOT NULL,
            accuracy REAL NOT NULL,
            subject TEXT NOT NULL
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database
init_db()

# 4. Retrieve a Random Flashcard
def get_random_flashcard(subject="韓文", language="韓文", exclude_ids=[], correct_ids=[]):
    """
    Retrieve one random flashcard (id, question, answer) from the database based on the subject and language,
    excluding the ones that have been answered correctly.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    print(f"Querying for subject: {subject}, language: {language}, excluding IDs: {exclude_ids}, correct IDs: {correct_ids}")  # 調試輸出
    query = "SELECT id, question, answer FROM flashcards WHERE subject = ? AND language = ?"
    params = [subject, language]
    if exclude_ids:
        query += " AND id NOT IN ({})".format(",".join("?" * len(exclude_ids)))
        params.extend(exclude_ids)
    if correct_ids:
        query += " AND id NOT IN ({})".format(",".join("?" * len(correct_ids)))
        params.extend(correct_ids)
    query += " ORDER BY RANDOM() LIMIT 1"
    cursor.execute(query, params)
    card = cursor.fetchone()  # Returns a tuple (id, question, answer)
    print(f"Retrieved card: {card}")  # 調試輸出
    conn.close()
    return card

# 5. Flexible Answer Checking with NLP (Rapidfuzz)
def is_similar_answer(user_answer, correct_answer, threshold=80):
    """
    Compare user input with the correct answer and determine similarity.
    Args:
        user_answer (str): The answer provided by the user.
        correct_answer (str): The correct answer from the flashcard.
        threshold (int): Minimum similarity percentage to consider the answer correct.
    Returns:
        bool: True if similarity >= threshold, False otherwise.
        int: Similarity score for reference.
    """
    similarity = fuzz.ratio(user_answer.lower(), correct_answer.lower())
    return similarity >= threshold, similarity

# 6. Flask Routes (Backend Logic)
# 修正 Flask 回傳的亂碼問題
from flask import Flask, render_template, request, redirect, url_for, session

# Initialize Flask App
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 用於加密 session

from flask import Flask, render_template, request, redirect, url_for, session

@app.route("/", methods=["GET", "POST"])
def flashcard():
    if 'correct_count' not in session:
        session['correct_count'] = 0
    if 'wrong_count' not in session:
        session['wrong_count'] = 0
    if 'question_count' not in session:
        session['question_count'] = 0
    if 'answered_ids' not in session:
        session['answered_ids'] = []
    if 'correct_ids' not in session:
        session['correct_ids'] = []
    if 'cycle_number' not in session:
        session['cycle_number'] = 1

    message = ""  # 回饋訊息
    subject = request.args.get("subject", "韓文")  # 根據需要設置科目
    language = request.args.get("language", "韓文")  # 根據需要設置語言
    card = get_random_flashcard(subject, language, session['answered_ids'], session['correct_ids'])

    print(f"Subject: {subject}, Language: {language}")
    print(f"Card: {card}")  # 調試輸出

    if request.method == "POST":
        user_answer = request.form.get("user_answer")
        correct_answer = request.form.get("correct_answer")
        card_id = request.form.get("card_id")
        
        is_correct, similarity = is_similar_answer(user_answer, correct_answer)
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        if is_correct:
            message = f"🎉 答對了！(相似度: {similarity}%)"
            cursor.execute("INSERT INTO stats (correct, wrong, subject) VALUES (1, 0, ?)", (subject,))
            session['correct_count'] += 1
            session['correct_ids'].append(int(card_id))  # 記錄已答對的題目 ID
        else:
            message = f"❌ 答錯了！正確答案是：{correct_answer} (相似度: {similarity}%)"
            cursor.execute("INSERT INTO stats (correct, wrong, subject) VALUES (0, 1, ?)", (subject,))
            session['wrong_count'] += 1

        session['question_count'] += 1
        session['answered_ids'].append(int(card_id))  # 記錄已回答的題目 ID

        cursor.execute("SELECT explanation FROM flashcards WHERE id = ?", (card_id,))
        explanation = cursor.fetchone()
        message += f" 提示：{explanation[0] if explanation else '無解釋'}"

        conn.commit()
        conn.close()

        # 每回答十個問題後，顯示結果並給予建議
        if session['question_count'] == 10:
            correct_count = session['correct_count']
            wrong_count = session['wrong_count']
            accuracy = correct_count / 10 * 100
            message += f" 你已經回答了10個問題，正確：{correct_count}，錯誤：{wrong_count}，正確率：{accuracy}%"
            
            # 根據正確率給予建議
            if accuracy >= 80:
                message += " 很棒！繼續照這步調！"
            elif accuracy >= 50:
                message += " 你這樣不行ㄟ，快點進步!"
            else:
                message += " 錯一半以上，要不要學韓文阿！"

            # 記錄循環的正確率
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO cycles (cycle_number, accuracy, subject) VALUES (?, ?, ?)",
                           (session['cycle_number'], accuracy, subject))
            conn.commit()
            conn.close()

            # 更新循環次數
            session['cycle_number'] += 1

            # 生成學習曲線圖
            generate_learning_curve(subject)

            session['correct_count'] = 0
            session['wrong_count'] = 0
            session['question_count'] = 0
            session['answered_ids'] = []  # 重置已回答的題目 ID
            session['correct_ids'] = []  # 重置已答對的題目 ID

    # 確保 message 編碼正確
    message = message.encode('utf-8').decode('utf-8')
    return render_template("flashcard.html", card=card, message=message)


@app.route("/manage_flashcards")
def manage_flashcards():
    """
    Route to manage (view, edit, delete) flashcards.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, question, answer, subject, language FROM flashcards")
    flashcards = cursor.fetchall()
    conn.close()
    return render_template("manage_flashcards.html", flashcards=flashcards)

@app.route("/add_flashcard", methods=["GET", "POST"])
def add_flashcard():
    """
    Route to add a new flashcard through a web form.
    """
    message = ""
    if request.method == "POST":
        question = request.form.get("question")
        answer = request.form.get("answer")
        subject = request.form.get("subject", "韓文")
        language = request.form.get("language", "韓文")
        explanation = request.form.get("explanation", "")

        if question and answer:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO flashcards (question, answer, subject, language, explanation) VALUES (?, ?, ?, ?, ?)",
                           (question, answer, subject, language, explanation))
            conn.commit()
            conn.close()
            message = "題目已成功新增！"
        else:
            message = "請完整填寫所有欄位！"
    return render_template("add_flashcard.html", message=message)

@app.route("/edit_flashcard/<int:id>", methods=["GET", "POST"])
def edit_flashcard(id):
    """
    Route to edit an existing flashcard.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    if request.method == "POST":
        question = request.form.get("question")
        answer = request.form.get("answer")
        subject = request.form.get("subject")
        language = request.form.get("language")
        explanation = request.form.get("explanation")

        cursor.execute("UPDATE flashcards SET question = ?, answer = ?, subject = ?, language = ?, explanation = ? WHERE id = ?",
                       (question, answer, subject, language, explanation, id))
        conn.commit()
        conn.close()
        return redirect(url_for("manage_flashcards"))

    cursor.execute("SELECT question, answer, subject, language, explanation FROM flashcards WHERE id = ?", (id,))
    flashcard = cursor.fetchone()
    conn.close()
    return render_template("edit_flashcard.html", flashcard=flashcard, id=id)

@app.route("/delete_flashcard/<int:id>")
def delete_flashcard(id):
    """
    Route to delete an existing flashcard.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM flashcards WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for("manage_flashcards"))

@app.route("/stats")
def stats():
    """
    Display learning statistics in graphical format.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT correct, wrong FROM stats")
    data = cursor.fetchall()
    conn.close()

    correct = sum([row[0] for row in data])
    wrong = sum([row[1] for row in data])

    # Pie chart
    labels = ['Correct', 'Wrong']
    sizes = [correct, wrong]
    colors = ['#4CAF50', '#FF6F61']
    explode = (0.1, 0)

    plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
    plt.axis('equal')

    # Save chart
    chart_path = "static/stats_pie_chart.png"
    plt.savefig(chart_path)
    plt.close()

    return render_template("stats.html", chart_path=chart_path)

@app.route("/select_language", methods=["GET", "POST"])
def select_language():
    if request.method == "POST":
        language = request.form.get("language")
        return redirect(url_for("flashcard", language=language))
    return render_template("select_language.html")

@app.route("/learning_curve")
def learning_curve():
    """
    Display learning curve based on accuracy of each 10-question cycle.
    """
    subject = request.args.get("subject", "韓文")  # 根據需要設置科目
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT cycle_number, accuracy FROM cycles WHERE subject = ?", (subject,))
    data = cursor.fetchall()
    conn.close()

    cycle_numbers = [row[0] for row in data]
    accuracies = [row[1] for row in data]

    # Plot learning curve
    plt.figure(figsize=(10, 6))
    plt.plot(cycle_numbers, accuracies, marker='o', linestyle='-', color='b')
    plt.xlabel('Cycle Number')
    plt.ylabel('Accuracy (%)')
    plt.title(f'Learning Curve for {subject}')
    plt.grid(True)

    # Save chart
    chart_path = "static/learning_curve.png"
    plt.savefig(chart_path)
    plt.close()

    return render_template("learning_curve.html", chart_path=chart_path)

def generate_learning_curve(subject):
    """
    Generate learning curve based on accuracy of each 10-question cycle.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT cycle_number, accuracy FROM cycles WHERE subject = ?", (subject,))
    data = cursor.fetchall()
    conn.close()

    cycle_numbers = [row[0] for row in data]
    accuracies = [row[1] for row in data]

    # Plot learning curve
    plt.figure(figsize=(10, 6))
    plt.scatter(cycle_numbers, accuracies, color='b')
    plt.xlabel('Cycle Number (x10 questions)')
    plt.ylabel('Accuracy (%)')
    plt.title(f'Learning Curve for {subject}')
    plt.grid(True)
    plt.xticks(range(0, max(cycle_numbers) + 1 if cycle_numbers else 1, 1))  # 確保橫軸的最小單位為十
    plt.yticks(range(0, 101, 10))  # 設置縱軸的範圍和刻度
    plt.ylim(0, 100)  # 設置縱軸的最小值和最大值

    # Save chart
    chart_path = os.path.join("static", "learning_curve.png")
    plt.savefig(chart_path)
    plt.close()

@app.route("/reset_chart")
def reset_chart():
    """
    Route to reset the learning curve chart data.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM cycles")
    conn.commit()
    conn.close()

    # 重新生成空的學習曲線圖
    generate_learning_curve("韓文")  # 根據需要設置科目

    return redirect(url_for("manage_flashcards"))

# 7. Start the Flask App
if __name__ == "__main__":
    app.run(debug=True)





